package com.mercadolibre.mutantdetector.service;

import com.mercadolibre.mutantdetector.entity.DnaRecord;
import com.mercadolibre.mutantdetector.repository.DnaRecordRepository;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Optional;


@Service
public class MutantService {

    private final MutantDetector mutantDetector;
    private final DnaRecordRepository dnaRecordRepository;

    public MutantService(MutantDetector mutantDetector, DnaRecordRepository dnaRecordRepository) {
        this.mutantDetector = mutantDetector;
        this.dnaRecordRepository = dnaRecordRepository;
    }

    public boolean isMutant(String[] dna) {
        // Verificar si ya existe en la base de datos
        String dnaHash = calculateDnaHash(dna);
        Optional<DnaRecord> existingRecord = dnaRecordRepository.findByDnaHash(dnaHash);

        if (existingRecord.isPresent()) {
            return existingRecord.get().isMutant();
        }

        // Detectar si es mutante
        boolean isMutant = mutantDetector.isMutant(dna);

        // Guardar en base de datos
        DnaRecord dnaRecord = new DnaRecord(dna, dnaHash, isMutant);
        dnaRecordRepository.save(dnaRecord);

        return isMutant;
    }

    private String calculateDnaHash(String[] dna) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String dnaString = Arrays.toString(dna);
            byte[] hash = md.digest(dnaString.getBytes());

            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error calculating DNA hash", e);
        }
    }
}