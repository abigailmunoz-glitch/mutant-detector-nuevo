package com.mercadolibre.mutantdetector.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class DnaRequest {

    @NotNull(message = "El ADN no puede ser nulo")
    @Size(min = 4, message = "El ADN debe tener al menos 4 filas")
    private String[] dna;
}