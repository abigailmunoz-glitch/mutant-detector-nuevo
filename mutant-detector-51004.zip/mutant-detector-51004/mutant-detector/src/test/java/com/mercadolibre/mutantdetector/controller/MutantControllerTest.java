package com.mercadolibre.mutantdetector.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mercadolibre.mutantdetector.dto.DnaRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class MutantControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void whenInvalidDna_thenReturns400() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(null);

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenMutantDna_thenReturns200() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"ATGCGA", "CAGTGC", "TTATGT", "AGAAGG", "CCCCTA", "TCACTG"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }

    @Test
    void whenHumanDna_thenReturns403() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"ATGCGA", "CAGTGC", "TTATTT", "AGACGG", "GCGTCA", "TCACTG"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isForbidden());
    }

    @Test
    void whenEmptyDna_thenReturns400() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenDnaWithInvalidChars_thenReturns400() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"ATGCGA", "CAGTGC", "TTATGT", "AGAXGG", "CCCCTA", "TCACTG"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenDnaNotSquare_thenReturns400() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"ATGCGA", "CAGTGC", "TTATGT"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenMutantDiagonal_thenReturns200() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"ATGCGA", "CAGTGC", "TTATGT", "AGAAGG", "CCCCTA", "TCACTG"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }

    @Test
    void whenStatsEndpoint_thenReturns200() throws Exception {
        mockMvc.perform(get("/api/v1/stats"))
                .andExpect(status().isOk());
    }

    @Test
    void whenStatsEndpoint_thenReturnsValidStructure() throws Exception {
        mockMvc.perform(get("/api/v1/stats"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.count_mutant_dna").exists())
                .andExpect(jsonPath("$.count_human_dna").exists())
                .andExpect(jsonPath("$.ratio").exists());
    }


    @Test
    void whenDnaWithLowercaseLetters_thenReturns400() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"atgcga", "CAGTGC", "TTATGT", "AGAAGG", "CCCCTA", "TCACTG"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenDnaWithEmptyRow_thenReturns400() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"ATGCGA", "", "TTATGT", "AGAAGG", "CCCCTA", "TCACTG"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenDnaWithDifferentRowLengths_thenReturns400() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"ATGCGA", "CAGTGC", "TTATGT", "AGAAG", "CCCCTA", "TCACTG"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

}