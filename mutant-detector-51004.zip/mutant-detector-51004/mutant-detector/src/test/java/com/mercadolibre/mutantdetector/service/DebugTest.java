package com.mercadolibre.mutantdetector.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DebugTest {

    @Test
    void debugSimpleCase() {
        MutantDetector detector = new MutantDetector();

        // Caso MUY simple - 4 A's horizontales
        String[] simpleDna = {
                "AAAA",
                "TTTT",
                "CCCC",
                "GGGG"
        };

        boolean result = detector.isMutant(simpleDna);
        System.out.println("Simple case result: " + result);
        assertTrue(result, "Should detect mutant in simple case");
    }


}